#include "ui.h"
#include "tests.h"
#include "service.h"


int main() {
    testall();
    Service service;
    UI ui(service);
    ui.run();
    return 0;
}