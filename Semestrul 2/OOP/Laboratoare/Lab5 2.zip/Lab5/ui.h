#ifndef ui_h

#define ui_h
#include "controller.h"



void Ruleaza_Meniu();
void Adauga_Valori_Repo(Controller* ctrl);
void Afiseaza_Imobile(Controller* ctrl);
#endif // !1
