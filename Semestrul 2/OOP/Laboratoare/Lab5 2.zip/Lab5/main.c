#include "ui.h"
#include "tests.h"
#include <stdio.h>

int main(void)
{
    //Ruleaza_Teste();
    Ruleaza_Meniu();
    return 0;
}
