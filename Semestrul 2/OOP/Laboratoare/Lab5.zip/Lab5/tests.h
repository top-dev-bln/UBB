#ifndef TESTS_H

#define TESTS_H

void Ruleaza_Teste();
void Teste_Domain();
void Teste_Repo();
void Test_Controller();
void Teste_Validator();

#endif
