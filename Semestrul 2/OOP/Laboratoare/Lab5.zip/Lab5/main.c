
#include "ui.h"
#include "tests.h"


int main(void)
{
	/* Ruleaza aplicatia
	 * argc: numarul de argumente
	 * argv: argumentele
	 */

	Ruleaza_Teste();
	Ruleaza_Meniu();

	return 0;
}
