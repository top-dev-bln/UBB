//
// Created by Balan Andrei Daniel on 03.04.2025.
//

#ifndef TESTS_H
#define TESTS_H

void testall();

#endif //TESTS_H
