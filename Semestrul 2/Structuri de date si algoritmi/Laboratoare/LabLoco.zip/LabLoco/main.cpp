
#include "TestExtins.h"
#include "TestScurt.h"
#include <iostream>
using namespace std;

int main() {

    testAll();
    testAllExtins();

    cout << "That's all!" << endl;

}
